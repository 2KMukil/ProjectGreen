package greenbus;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

public class Payment {
	

  String credit;
 Date expiry; 
  String cvv;
  String Name;
 
  
  String upi;
 
 int pay;
   
   Payment(){
	   
	   Scanner sc = new Scanner(System.in);
	   System.out.println("-----------------------");
	   System.out.println("    ");
	System.out.println("------  PAYMENT  ------");
	System.out.println("    ");
	   System.out.println("Enter 1 to pay with credit card");
	   System.out.println("Enter 2 to pay with UPI");
	   System.out.println("Enter 3 to pay with cash");
	    pay=sc.nextInt();
	   if(pay==1) {	 
		   //this code will run after user enters 1
		   System.out.println("----------------");
		   System.out.println("Enter the Credit Card No");
		   credit=sc.next();
			while (!credit.matches("\\d+") || credit.length() != 16) {
			    System.out.println("ERROR ::Please enter a valid 16-digit credit card Number: ");
			    credit = sc.next();
			}
		 
		   System.out.println("Enter the CVV");
		   cvv=sc.next();
		   while (!cvv.matches("\\d+") || cvv.length() != 3) {
			    System.out.println("ERROR ::Please enter a valid 3-digit cvv Number: ");
			    cvv = sc.next();
		   }
		   
		   System.out.println("Enter the Name on card");
		   Name=sc.next();	  
		   System.out.println("    ");
		  // System.out.println("Enter the expiry date (MM/YY)");
		  // expiry =sc.next();
		   while (true) {
			    System.out.println("Enter a Exipry date of card(MM/yy): ");
			    String expiry1= sc.next();

			    SimpleDateFormat dateFormat = new SimpleDateFormat("MM/yy");
			    dateFormat.setLenient(false);

			  
			    try {
			        expiry = dateFormat.parse(expiry1);
			    } catch (ParseException e) {
			        System.out.println("ERROR ::Invalid date format");
			        continue;
			    }

			    Date currentDate = new Date();

			    if (expiry.before(currentDate)) {
			        System.out.println("ERROR ::Date has expired");
			        System.out.println("Enter a valid date");
			       // break;
			    } else {
			        System.out.println("Booking.....");
			        break;
			    }
			}
		   System.out.println("Your Payment is Successful");
		   System.out.println("    ");
			System.out.println("Processing your Confirmation...");
			System.out.println("     ");
			
		   }
	   
	   if(pay==2) {
		   //this code will run after user enters 2
		   System.out.println("----------------");
		  // System.out.println("Enter the UPI id ");
		 //  upi = sc.next();
		   
		   System.out.println("Enter the UPI Linked Mobile number");
			upi = sc.next();
			while (!upi.matches("\\d+") || upi.length() != 10) {
			    System.out.println("ERROR :: Please enter a valid UPI mobile number: ");
			   upi = sc.next();
			}
			 System.out.println("Your Payment is Successful");
			   System.out.println("    ");
				System.out.println("Processing your Confirmation...");
				System.out.println("     ");

		   
			

			 //   if (upi.matches("^[\\w.-]+@[\\w]+\\.[\\w]{2,}$")) {
			       
			        
			  
		   }
		
			
	  
	   
	   
	   if(pay==3){
		   //this code will run after user enters 3
		   System.out.println("----------------");
		   System.out.println("Pay the Cash while Boarding");
		   System.out.println("    ");
	   }
   }
}
