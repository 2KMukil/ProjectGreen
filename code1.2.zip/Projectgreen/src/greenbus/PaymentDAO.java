package greenbus;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.SQLException;

public class PaymentDAO {

	public void addpayment(Payment payment,java.util.Date expiry) throws SQLException {
		// TODO Auto-generated method stub
		//this code will enter all the details into the tables 
		String query = "Insert into Payment values(?,?,?,?)";
		String query1 =  "Insert into UPI values (?)";
		Connection con = DbConnection.getConnection();
		if(payment.pay==1) {
		PreparedStatement pst = con.prepareStatement(query);
		java.sql.Date sqldate = new java.sql.Date(expiry.getTime());
		pst.setString(1, payment.credit);
		pst.setDate(2,sqldate);
		pst.setString(3, payment.cvv); 
		pst.setString(4,payment.Name);
		pst.executeUpdate();
		}
		
		if(payment.pay==2){
		PreparedStatement pst1 =con.prepareStatement(query1);
		pst1.setString(1, payment.upi);	
		//pst1.setString(2, payment.name);
		pst1.executeUpdate();
		
	}

}
}
