package greenbus;

import java.sql.Time;

public class Bus {
	private int busNo;
	private String fromCity;
	private String toCity;
	private String busType;
	private Time boardingtime;
	private int BusCapacity; 
	 
	
	Bus(int no,String FC,String TC,String Type,Time Boarding,int cap){
		this.busNo = no;
		this.fromCity=FC;
		this.toCity=TC;
		this.busType= Type;
		this.boardingtime= Boarding;
		this.BusCapacity = cap; 
		
	}
	
	public int getBusNo(){ 
		return busNo;
	}
	
	public String getFromCity(){
		return fromCity;
	}
	public String getToCity() {
		return toCity;
	}
	public String getBusType(){
		return busType;
	}
	public Time getBoardingTime() {
		return boardingtime;
	}
	public int getNoOfSeatsLeft(){ 
		return BusCapacity;
	}
	
	
	
	public void setBusNo(int no) { 
		busNo = no;
	}
	public void setFromCity(String FC) { 
		fromCity = FC;
	}
	public void setToCity(String TC) { 
		toCity = TC;
	}
	public void setBusType(String Type) { 
		busType = Type;
	}
	public void setBoardingTime(Time Boarding) { 
		boardingtime = Boarding;
	}
	
	public void setNoOfSeatsLeft(int cap) {
	
		BusCapacity = cap;
	}
	
	
}