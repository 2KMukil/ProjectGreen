package greenbus;

import java.sql.*;

public class BusDAO {
	//this code will displays the bus details from database
	public void displayBusInfo() throws SQLException {
		String query = "Select * from BUS";
		Connection con = DbConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
		 
		while(rs.next()) {
			System.out.println("      ");
			System.out.println("Bus No: " + rs.getInt(1));
			System.out.println("      ");
			System.out.println("From City: "+rs.getString(2));
			System.out.println("      ");
			System.out.println("To City: "+rs.getString(3));
			System.out.println("      ");
			System.out.println("Bus Type: "+rs.getString(4));
			System.out.println("      ");
			System.out.println("Boarding Time: "+rs.getTime(5));
			System.out.println("      ");
			System.out.println("BusCapacity: " + rs.getInt(6));
			System.out.println("      ");
			System.out.println("Fare: ₹"+rs.getInt(7));
			System.out.println("      ");
			System.out.println("-----------------");
		}
		       System.out.println("      ");
			System.out.println("------  BOOKING DETAILS  -------");
		
		
		
	}
	
	public int getCapacity(int id) throws SQLException {
		String query = "Select BusCapacity from BUS where BUSNO =" + id;
		Connection con = DbConnection.getConnection();
		Statement st = con.createStatement();
		ResultSet rs = st.executeQuery(query);
		rs.next();
		return rs.getInt(1);
	}
}