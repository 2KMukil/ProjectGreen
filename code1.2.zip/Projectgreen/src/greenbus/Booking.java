package greenbus;

import java.util.*;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat; 
public class Booking {
	String passengerName;
	 int busNo;
	Date date;
   String mobileno;
    String email; 
	
	Booking(){
		//this code will collect all the details from user to book
		Scanner scanner = new Scanner(System.in);
		System.out.println("  ");
		System.out.println("Enter name of passenger: ");
		passengerName = scanner.next();
		
		
		 
		System.out.println("Enter the Mobile number");
		mobileno = scanner.next();
		while (!mobileno.matches("\\d+") || mobileno.length() != 10) {
		    System.out.println("ERROR ::Please enter a valid 10-digit mobile number: ");
		    mobileno = scanner.next();
		}
		
		
		
		
		System.out.println("Enter your Email-ID");
		email = scanner.next();
		while (!email.matches("^[\\w-_\\.+]*[\\w-_\\.]\\@([\\w]+\\.)+[\\w]+[\\w]$")) {
		    System.out.println("ERROR ::Please enter a valid Email: ");
		    email = scanner.next();
		}
		
		System.out.println("Enter bus no: ");
		busNo = scanner.nextInt();
		
		
	//	System.out.println("Enter date dd-mm-yyyy");
		//String dateInput = scanner.next();
		
		   // System.out.println("Enter an expiration date in the format dd/MM/yyyy: ");
		   // String expirationDateString = scanner.nextLine();
		while (true) {
		    System.out.println("Enter a date of travel (dd-MM-yyyy): ");
		    String dateInput = scanner.next();

		    SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		    dateFormat.setLenient(false);

		  
		    try {
		        date = dateFormat.parse(dateInput);
		    } catch (ParseException e) {
		        System.out.println("ERROR ::Invalid date format");
		        continue;
		    }

		    Date currentDate = new Date();

		    if (date.before(currentDate)) {
		        System.out.println("ERROR ::Date has expired");
		        System.out.println("Enter a valid date");
		       // break;
		    } else {
		        System.out.println("Booking.....");
		        break;
		    }
		}

		}
		     
		    	     
		    
		    	
		    
		  //  System.out.println("Enter your Mobile Number");
			
		     
		
		    	
		
		         
		      //  break;
		    
		



	//	SimpleDateFormat dateFormat = new SimpleDateFormat("dd-MM-yyyy");
		
	//	try {
	//		date = dateFormat.parse(dateInput);
	//	} catch (ParseException e) {
			// TODO Auto-generated catch block
	//		e.printStackTrace();
	//	}  
		
		
		
		
		
		
	
	
	
	public boolean isAvailable()  throws SQLException{
		//this code will get whether bus is filled 
		BusDAO busdao = new BusDAO();
		BookingDAO bookingdao = new BookingDAO();
		
		int BusCapacity = busdao.getCapacity(busNo);
		
      
        
		int booked = bookingdao.getBookedCount(busNo,date);
		
		      return booked<BusCapacity;
		      
		      
		}
	
	}
		


	

