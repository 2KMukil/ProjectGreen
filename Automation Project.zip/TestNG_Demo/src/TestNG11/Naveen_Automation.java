package TestNG11;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.concurrent.TimeUnit;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.opera.OperaDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.testng.Assert;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.google.common.io.Files;

 

public class Naveen_Automation {
    ExtentSparkReporter report;
    ExtentReports extent;
    ExtentTest test;
    WebDriver driver;

 

    @BeforeTest
    public void setup() {
    	//this path is extend report
        String path = ("C:\\Users\\kumpati.raju\\Downloads\\TestNG_Demo\\test-output\\naveen_automationreport.html");
        report = new ExtentSparkReporter(path);
        extent = new ExtentReports();
        extent.attachReporter(report);
        test = extent.createTest("Naveen Automation");
    }

 

    @Test(priority = 1)
    public void register() {
        //Chrome Broswer Launched
        WebDriver driver;
        System.setProperty("webdriver.chrome.driver",
                "C:\\Users\\kumpati.raju\\Downloads\\chromedriver_win32\\chromedriver.exe");
        test.info("Chrome Browser Launched ");
        driver = new ChromeDriver();
        test.info("Window Maximized");
        driver.manage().window().maximize();
        // Code for Registration Page
        test.info("Naveen Automation Lab URL Loaded");
        driver.get("https://naveenautomationlabs.com/opencart/index.php?route=common/home");
        System.out.println("Welcome to Home Page");
        driver.navigate().to("https://naveenautomationlabs.com/opencart/index.php?route=account/register");
        driver.findElement(By.id("input-firstname")).sendKeys("Nirmal");
        Assert.assertEquals(true, true);
        driver.findElement(By.id("input-lastname")).sendKeys("Pandu");
        Assert.assertEquals(true, true);
        driver.findElement(By.id("input-email")).sendKeys("nirmalkumpati@gmail.com");
        Assert.assertEquals(true, true);
        driver.findElement(By.id("input-telephone")).sendKeys("7569414351");
        Assert.assertEquals(true, true);
        driver.findElement(By.id("input-password")).sendKeys("Nirmal@143");
        Assert.assertEquals(true, true);
        driver.findElement(By.id("input-confirm")).sendKeys("Nirmal@143");
        Assert.assertEquals(true, true);
        // Code for I have read and agree to the Privacy Policy Check Box
        WebElement check = driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[1]"));
        check.click();
        //Code for Submission Button
        WebElement submit = driver.findElement(By.xpath("//*[@id=\"content\"]/form/div/div/input[2]"));
        submit.click();
        //Url Navigate to Loing Page
        driver.navigate().to("https://naveenautomationlabs.com/opencart/index.php?route=account/login");
        System.out.println("Registration Completed ");
        Assert.assertEquals(true, true);
        test.pass("Regestration Successfull");
    }

 

    @Test(priority = 2)
    public void login() throws IOException {
        System.setProperty("webdriver.opera.driver",
                "C:\\Users\\kumpati.raju\\Downloads\\operadriver_win64\\operadriver_win64\\operadriver.exe");
        driver = new ChromeDriver();
        test.info("Window Maximized");
        driver.manage().window().maximize();
        test.info("Login Page Opended");
        //Login page will be Opended
        driver.get("https://naveenautomationlabs.com/opencart/index.php?route=account/login");
        // code for Apachi_poi( Data Driven framework )
        FileInputStream fis = new FileInputStream(
                new File("C:\\Users\\kumpati.raju\\OneDrive - HCL Technologies Ltd\\Desktop\\Automation.xlsx"));
        XSSFWorkbook wrb = new XSSFWorkbook(fis);
        XSSFSheet sh = wrb.getSheet("Automation");
        // Code for Login & Getting Data from Back End from Excel Sheet 
        driver.findElement(By.id("input-email")).sendKeys(sh.getRow(1).getCell(2).getStringCellValue());
        driver.findElement(By.id("input-password")).sendKeys(sh.getRow(3).getCell(2).getStringCellValue());
        WebElement submit = driver.findElement(By.xpath("//*[@id=\"content\"]/div/div[2]/div/form/input"));
        submit.click();
        System.out.println("Login Success");
        //Login Success
        WebElement accesories = driver.findElement(By.xpath("//*[@id=\"menu\"]/div[2]/ul/li[6]/a"));
        accesories.click();
        Assert.assertEquals(true, true);
        test.pass("Login Successfully");
    }
    
    @Test(priority = 3)
    public void Checkout() throws InterruptedException, IOException {

 

        // code for Cross Browser Testing open's Opera Driver
        System.setProperty("webdriver.opera.driver",
                "C:\\Users\\kumpati.raju\\Downloads\\operadriver_win64\\operadriver_win64\\operadriver.exe");
        driver = new OperaDriver();
        test.info("Window Maximized");
        driver.manage().window().maximize();
        test.info("Product URL Opended");
        try {
            // code for Product Page
            driver.navigate().to(
                    "https://naveenautomationlabs.com/opencart/index.php?route=product/product&path=24&product_id=29");
            WebElement cart = driver.findElement(By.xpath("//*[@id=\"button-cart\"]"));
            Thread.sleep(2000);
            cart.click();
            //code for Shopping Page
            WebElement shopcart = driver.findElement(By.xpath("//*[@id=\"top-links\"]/ul/li[4]/a/i"));
            Thread.sleep(2000);
            shopcart.click();
            //code for Confirming product
            WebElement item = driver.findElement(By.xpath("//*[@id=\"cart\"]/button"));
            Thread.sleep(2000);
            item.click();
            test.info("Product Confirmed");
            WebElement checkout = driver.findElement(By.xpath("//*[@id=\"cart\"]/ul/li[2]/div/p/a[2]/strong"));
            Thread.sleep(2000);
            checkout.click();
            test.info("Check Out Page Opended");
            // Code for Check Out Page
            driver.navigate().to("https://naveenautomationlabs.com/opencart/index.php?route=checkout/checkout");
            driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
            //code Login credentials 
            driver.findElement(By.id("input-email")).sendKeys("nirmalkumpati@gmail.com");
            Assert.assertEquals(true, true);
            driver.findElement(By.id("input-password")).sendKeys("Nirmal@143");
            Assert.assertEquals(true, true);
            driver.findElement(By.id("button-login")).click();
            // After Login it will enable payment address
            driver.findElement(By.name("payment_address")).click();
            //this will click on payment address
            driver.findElement(By.id("button-payment-address")).click();
            // this will click on shipping address
            driver.findElement(By.id("button-shipping-address")).click();
            driver.findElement(By.id("button-shipping-method")).click();
            // Code for Order Confirmation
            WebElement cont = driver
                    .findElement(By.xpath("//*[@id=\"collapse-payment-method\"]/div/div[2]/div/input[1]"));
            cont.click();
            driver.findElement(By.id("button-payment-method")).click();
            driver.findElement(By.id("button-confirm")).click();
            WebElement Shippingaddress = driver.findElement(By.id("button-shipping-method"));
            /*
             * WebDriverWait wait = new WebDriverWait(driver, 20);
             * wait.until(ExpectedConditions.refreshed(ExpectedConditions.stalenessOf(
             * Shippingaddress)))
             */
            //code for shipping 
            driver.findElement(By.id("button-shipping-method ")).click();
            test.info("Shipping Page Loaded");
            // Code for Order Confirmation
            WebElement term = driver
                    .findElement(By.xpath("//*[@id=\"collapse-payment-method\"]/div/div[2]/div/input[1]"));
            term.click();
            driver.findElement(By.id("button-payment-method")).click();
            driver.findElement(By.id("button-confirm")).click();
        } catch (Exception e) {
            System.out.println(e);
        }
        test.pass("Order Confired");
        //this code will take screenshot
        TakesScreenshot scrShot = ((TakesScreenshot) driver);
        File SourceFile = scrShot.getScreenshotAs(OutputType.FILE);
        File DestFile = new File("C:\\Users\\kumpati.raju\\Downloads\\TestNG_Demo\\ScreenShot\\Naveen_Automation.png");
        Files.copy(SourceFile, DestFile);
    }

 

    

 

    @AfterTest
    public void closetest() {
        driver.quit();
        extent.flush();
    }
}